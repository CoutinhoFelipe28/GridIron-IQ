"""
players_layer.py - Efetividade individual de jogadores para a decisão.
======================================================================

Complementa a recomendação de jogada com o fator humano:

  - Ameaças de pass rush (defesa): quem mais pressiona o QB. O treinador
    ofensivo usa isso para reforçar a proteção onde há risco.
  - Confiabilidade de proteção (ataque): quais bloqueadores seguram melhor,
    para decidir de que lado atacar/proteger.

Baseia-se em prepare_player_effectiveness() do data_prep.
"""

import pandas as pd

from data_prep import load_raw, prepare_player_effectiveness


def _perfil_txt(row):
    """Monta a linha de perfil: nascimento (idade), altura, peso."""
    partes = []

    birth = row.get("birthDate")
    idade = row.get("idade")
    if pd.notna(birth):
        if pd.notna(idade):
            partes.append(f"nasc. {birth} ({int(idade)} anos)")
        else:
            partes.append(f"nasc. {birth}")
    else:
        partes.append("nasc. n/d")

    altura = row.get("height")
    partes.append(f"altura {altura}" if pd.notna(altura) else "altura n/d")

    peso = row.get("weight")
    partes.append(f"{int(peso)} lb" if pd.notna(peso) else "peso n/d")

    faculdade = row.get("collegeName")
    if pd.notna(faculdade):
        partes.append(str(faculdade))

    return " · ".join(partes)


class PlayersLayer:
    def __init__(self, pass_rush: pd.DataFrame, protection: pd.DataFrame):
        self.pass_rush = pass_rush
        self.protection = protection

    # -----------------------------------------------------------------
    def top_pass_rushers(self, top=10, min_jogadas=50):
        """Defensores mais efetivos em pressionar o QB (amostra mínima)."""
        df = self.pass_rush[self.pass_rush["jogadas"] >= min_jogadas]
        return df.sort_values("taxa_pressao", ascending=False).head(top)

    # -----------------------------------------------------------------
    def top_blockers(self, top=10, min_jogadas=50):
        """Bloqueadores mais confiáveis (maior taxa de proteção sem falha)."""
        df = self.protection[self.protection["jogadas"] >= min_jogadas]
        return df.sort_values("taxa_protecao", ascending=False).head(top)

    # -----------------------------------------------------------------
    def piores_blockers(self, top=10, min_jogadas=50):
        """Bloqueadores mais vulneráveis - pontos a proteger / atacar."""
        df = self.protection[self.protection["jogadas"] >= min_jogadas]
        return df.sort_values("taxa_protecao", ascending=True).head(top)

    # -----------------------------------------------------------------
    def resumo_para_decisao(self, top=5, perfil=False):
        """
        Texto de apoio: principais ameaças e pontos fortes.
        Se perfil=True, inclui os dados do jogador (nascimento/idade, altura,
        peso). Por padrão a estatística principal fica limpa.
        """
        rushers = self.top_pass_rushers(top=top)
        blockers = self.top_blockers(top=top)
        linhas = []
        linhas.append("AMEAÇAS DE PASS RUSH (reforçar proteção):")
        for _, r in rushers.iterrows():
            linhas.append(
                f"  - {r['displayName']} ({r['officialPosition']}): "
                f"{r['taxa_pressao']:.1%} de pressão em {int(r['jogadas'])} jogadas"
            )
            if perfil:
                linhas.append(f"      {_perfil_txt(r)}")
        linhas.append("")
        linhas.append("PROTEÇÃO MAIS CONFIÁVEL (lado seguro):")
        for _, b in blockers.iterrows():
            linhas.append(
                f"  - {b['displayName']} ({b['officialPosition']}): "
                f"{b['taxa_protecao']:.1%} de jogadas sem falha em {int(b['jogadas'])}"
            )
            if perfil:
                linhas.append(f"      {_perfil_txt(b)}")
        return "\n".join(linhas)


def build_players_layer():
    _plays, pff, players = load_raw()
    pass_rush, protection = prepare_player_effectiveness(pff, players)
    return PlayersLayer(pass_rush, protection)


if __name__ == "__main__":
    layer = build_players_layer()
    print(layer.resumo_para_decisao())
