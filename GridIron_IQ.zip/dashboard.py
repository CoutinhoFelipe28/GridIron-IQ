"""
GridIron IQ - Painel interativo de decisão de jogada (Streamlit + Plotly).
==========================================================================

Dashboard visual para o treinador, com:
  - Filtro por semana e por time (junta games.csv)
  - Seleção da situação de jogo (down, jardas, campo, cobertura)
  - Tabela de jogadas recomendadas + gráficos de efetividade
  - Painel de jogadores (pass rush e proteção) com gráficos

Como rodar (a partir da pasta coach_tool):
    py -m streamlit run dashboard.py

Abre no navegador (por padrão em http://localhost:8501).
"""

from pathlib import Path

import pandas as pd
import plotly.express as px
import plotly.graph_objects as go
import streamlit as st

from data_prep import (
    load_raw, prepare_plays, add_game_context,
    prepare_player_effectiveness, compute_player_ratings,
    ATRIBUTOS_RUSH, ATRIBUTOS_PROT, DESC_ATRIBUTOS,
    _distance_bucket, _field_bucket,
)
from recommender import PlayRecommender
from i18n import make_translator, attr_label


# ---------------------------------------------------------------------------
# Carregamento com cache (roda uma vez por sessão)
# ---------------------------------------------------------------------------
from urllib.parse import quote

HEADSHOTS_CSV = Path(__file__).resolve().parent / "headshots.csv"


@st.cache_data
def carregar():
    plays, pff, players = load_raw()
    dfp = prepare_plays(plays)
    dfp = add_game_context(dfp)  # adiciona week, homeTeamAbbr, visitorTeamAbbr
    pass_rush, protection = prepare_player_effectiveness(pff, players)
    ratings_rush, ratings_prot = compute_player_ratings(pass_rush, protection)

    # Mapa nome -> foto (media day). Gerado por build_headshots.py.
    fotos = {}
    if HEADSHOTS_CSV.exists():
        hs = pd.read_csv(HEADSHOTS_CSV)
        fotos = dict(zip(hs["displayName"], hs["headshot_url"]))

    return dfp, pass_rush, protection, ratings_rush, ratings_prot, fotos


dfp, pass_rush, protection, ratings_rush, ratings_prot, fotos = carregar()


def foto_de(nome):
    """
    Retorna a URL da foto (media day) do jogador. Se não houver headshot,
    gera um avatar com as iniciais do jogador (placeholder neutro).
    """
    url = fotos.get(nome)
    if isinstance(url, str) and url.strip():
        return url
    return (f"https://ui-avatars.com/api/?name={quote(str(nome))}"
            f"&background=012A54&color=ffffff&size=128&bold=true")


def principais_por_posicao(pos, topn=8):
    """
    Retorna os principais jogadores de uma posição (officialPosition),
    ordenados pela métrica mais relevante disponível:
      - Posições de pass rush (DE/DT/OLB/ILB/NT/MLB...) -> taxa de pressão.
      - Posições de bloqueio (T/G/C/TE/RB/FB)          -> taxa de proteção.
    Retorna DataFrame com colunas: displayName, métrica formatada, jogadas.
    """
    pos = str(pos)
    # pass rush primeiro
    r = pass_rush[pass_rush["officialPosition"] == pos]
    r = r[r["jogadas"] >= 30]
    if not r.empty:
        r = r.sort_values("taxa_pressao", ascending=False).head(topn).copy()
        r["valor"] = (r["taxa_pressao"] * 100).round(1)
        # tipo="rush" indica qual unidade/rótulo usar na exibição
        return r[["displayName", "valor", "jogadas"]], "rush"
    # proteção
    b = protection[protection["officialPosition"] == pos]
    b = b[b["jogadas"] >= 30]
    if not b.empty:
        b = b.sort_values("taxa_protecao", ascending=False).head(topn).copy()
        b["valor"] = (b["taxa_protecao"] * 100).round(1)
        return b[["displayName", "valor", "jogadas"]], "prot"
    return None, None


def _estrelas_txt(n):
    """Representação visual de 0-5 estrelas (com meia-estrela)."""
    if pd.isna(n):
        return "—"
    cheias = int(n)
    meia = (n - cheias) >= 0.5
    return "★" * cheias + ("½" if meia else "") + "☆" * (5 - cheias - (1 if meia else 0))


def _col_perfil(df):
    """
    Colunas de texto de perfil para o hover (tratando valores ausentes).
    Nascimento+idade, altura, peso e faculdade.
    """
    d = df.copy()
    d["_nasc"] = d.apply(
        lambda r: (f"{r['birthDate']} ({int(r['idade'])} anos)"
                   if pd.notna(r.get("birthDate")) and pd.notna(r.get("idade"))
                   else (str(r["birthDate"]) if pd.notna(r.get("birthDate")) else "n/d")),
        axis=1)
    d["_altura"] = d["height"].apply(lambda h: h if pd.notna(h) else "n/d")
    d["_peso"] = d["weight"].apply(lambda w: f"{int(w)} lb" if pd.notna(w) else "n/d")
    d["_faculdade"] = d["collegeName"].apply(lambda c: c if pd.notna(c) else "n/d")
    d["_foto"] = d["displayName"].apply(foto_de)
    return d


# ---------------------------------------------------------------------------
# Cabeçalho
# ---------------------------------------------------------------------------
st.set_page_config(page_title="GridIron IQ", page_icon="🏈", layout="wide")

# Paleta (fundo azul bem escuro + sotaques suaves).
NFL_BG = "#091026"        # fundo principal
NFL_PANEL = "#111A38"     # painéis/cards
NFL_RED_SOFT = "#C96A6A"  # vermelho suavizado (apenas sotaques discretos)
NFL_ACCENT = "#5B8FD6"    # azul claro (destaque principal)
NFL_WHITE = "#FFFFFF"
NFL_SILVER = "#A5ACAF"    # prata/cinza dos detalhes
# Escalas de cor dos gráficos: as cores originais (verde/vermelho/azul).
SCALE_ATAQUE = "Greens"   # jogadas
SCALE_RUSH = "Reds"       # pass rush (defesa)
SCALE_PROT = "Blues"      # proteção

# CSS para refinar a aparência (barra superior, títulos, tabelas, métricas).
st.markdown(f"""
<style>
    /* Fundo principal */
    .stApp {{
        background-color: {NFL_BG};
        border-top: 3px solid {NFL_RED_SOFT};
    }}
    h1, h2, h3 {{
        color: {NFL_WHITE};
        font-weight: 700;
        letter-spacing: 0.3px;
    }}
    /* Linha divisória em prata */
    hr {{ border-color: {NFL_SILVER}33; }}
    /* Cards de métrica com fundo de painel e borda sutil */
    div[data-testid="stMetric"] {{
        background: {NFL_PANEL};
        border: 1px solid {NFL_SILVER}44;
        border-radius: 8px;
        padding: 12px 14px;
    }}
    div[data-testid="stMetricValue"] {{ color: {NFL_WHITE}; }}
    div[data-testid="stMetricLabel"] {{ color: {NFL_SILVER}; }}
    div[data-testid="stAlertContentSuccess"] {{ color: {NFL_WHITE}; }}
    /* Painel de filtros no topo */
    .filtros-topo {{
        background: {NFL_PANEL};
        border: 1px solid {NFL_SILVER}33;
        border-radius: 10px;
        padding: 6px 14px 2px 14px;
        margin-bottom: 8px;
    }}
</style>
""", unsafe_allow_html=True)

# Seletor de idioma no canto superior direito (radio: só seleciona, não digita)
_esq, _dir = st.columns([5, 1])
with _dir:
    _lang_label = st.radio("🌐", ["PT-BR", "EN-US"], index=0, horizontal=True,
                           label_visibility="collapsed")
LANG = "en" if _lang_label == "EN-US" else "pt"
t = make_translator(LANG)

st.title(t("app_title"))
st.markdown(f"**{t('app_subtitle')}**")
st.caption(t("app_caption"))


def _estilo_plotly(fig):
    """Aplica fundo transparente e texto branco aos gráficos, no tema NFL."""
    fig.update_layout(
        paper_bgcolor="rgba(0,0,0,0)",
        plot_bgcolor="rgba(0,0,0,0)",
        font=dict(color=NFL_WHITE),
        title_font=dict(color=NFL_WHITE),
    )
    fig.update_xaxes(gridcolor=f"{NFL_SILVER}33", zerolinecolor=f"{NFL_SILVER}33")
    fig.update_yaxes(gridcolor=f"{NFL_SILVER}33", zerolinecolor=f"{NFL_SILVER}33")
    return fig


# ---------------------------------------------------------------------------
# Barra lateral: filtros de contexto e situação
# ---------------------------------------------------------------------------
# ---- Barra de filtros horizontal no topo ----
TODOS = t("all")
QUALQUER = t("any")

st.markdown(f"##### {t('sidebar_context')} · {t('sidebar_situation')}")

# Linha 1: contexto (semanas, time) + situação (down, jardas)
r1c1, r1c2, r1c3, r1c4 = st.columns([2, 1.4, 1, 1.4])
with r1c1:
    semanas = sorted(dfp["week"].dropna().unique().astype(int).tolist())
    sel_semanas = st.multiselect(t("weeks"), semanas, default=semanas)
with r1c2:
    times = sorted(dfp["possessionTeam"].dropna().unique().tolist())
    sel_time = st.selectbox(t("off_team"), [TODOS] + times)
with r1c3:
    down = st.selectbox(t("down"), [1, 2, 3, 4], index=2)
with r1c4:
    ytg = st.slider(t("ytg"), 1, 25, 8)

# Linha 2: cobertura, região do campo e nº de jogadas
r2c1, r2c2, r2c3, r2c4 = st.columns([1.4, 1, 1.4, 1.2])
with r2c1:
    coberturas = [QUALQUER] + sorted(dfp["pff_passCoverage"].dropna().unique().tolist())
    sel_cobertura = st.selectbox(t("coverage"), coberturas)
with r2c2:
    usar_campo = st.checkbox(t("filter_field"))
with r2c3:
    yardline = st.slider(t("yardline"), 1, 99, 50, disabled=not usar_campo)
with r2c4:
    top = st.slider(t("how_many"), 3, 10, 5)

st.divider()


# ---------------------------------------------------------------------------
# Aplica filtros de contexto (semana/time) antes de recomendar
# ---------------------------------------------------------------------------
df_ctx = dfp[dfp["week"].isin(sel_semanas)]
if sel_time != TODOS:
    df_ctx = df_ctx[df_ctx["possessionTeam"] == sel_time]

rec = PlayRecommender(df_ctx)

dist_bucket = _distance_bucket(ytg)
field_bucket = _field_bucket(yardline) if usar_campo else None
coverage = None if sel_cobertura == QUALQUER else sel_cobertura

tabela, nota, n = rec.recomendar(
    down=down, dist_bucket=dist_bucket,
    field_bucket=field_bucket, coverage=coverage, top=top)


# ---------------------------------------------------------------------------
# Painel principal: recomendação
# ---------------------------------------------------------------------------
dist_txt = t(f"dist_{dist_bucket}")
situacao = f"{down}º down · {ytg} {t('col_yards').lower()} ({dist_txt})"
if field_bucket:
    situacao += f" · {field_bucket}"
if coverage:
    situacao += f" · {coverage}"

st.subheader(t("recommended_plays"))
st.write(f"**{t('situation')}:** {situacao}")
st.write(f"**{t('hist_base')}:** {nota} — {n} {t('plays_analyzed')}")

if tabela.empty:
    st.warning(t("no_sample"))
else:
    tab_show = tabela.copy()
    tab_show["jogada"] = (tab_show["offenseFormation"].astype(str) + " / "
                          + tab_show["dropBackType"].astype(str)
                          + " (PA:" + tab_show["playAction"].astype(str) + ")")

    col1, col2 = st.columns([1.1, 1])

    with col1:
        st.dataframe(
            tab_show[["offenseFormation", "dropBackType", "playAction",
                      "jogadas", "score_medio", "jardas_media",
                      "taxa_sucesso", "taxa_sack", "taxa_int"]]
            .rename(columns={
                "offenseFormation": t("col_formation"), "dropBackType": t("col_dropback"),
                "playAction": t("col_playact"), "jogadas": t("col_n"),
                "score_medio": t("col_score"), "jardas_media": t("col_yards"),
                "taxa_sucesso": t("col_suc"), "taxa_sack": t("col_sack"),
                "taxa_int": t("col_int")}),
            use_container_width=True, hide_index=True)

    with col2:
        fig = px.bar(
            tab_show.sort_values("score_medio"),
            x="score_medio", y="jogada", orientation="h",
            color="taxa_sucesso", color_continuous_scale=SCALE_ATAQUE,
            labels={"score_medio": t("lbl_score"), "jogada": "",
                    "taxa_sucesso": t("lbl_success")},
            title=t("chart_effectiveness"))
        fig.update_layout(height=350, margin=dict(l=10, r=10, t=40, b=10))
        st.plotly_chart(_estilo_plotly(fig), use_container_width=True)

    melhor = tabela.iloc[0]
    st.success(
        f"**{t('suggestion')}:** {melhor['offenseFormation']} / {melhor['dropBackType']} "
        f"(play-action: {melhor['playAction']}) — "
        f"{melhor['jardas_media']:.1f} {t('avg_yards')}, "
        f"{melhor['taxa_sucesso']:.0%} {t('success_of')}, "
        f"{t('sack_risk')} {melhor['taxa_sack']:.0%}.")


# ---------------------------------------------------------------------------
# Barra de pesquisa de JOGADAS
# ---------------------------------------------------------------------------
st.divider()
st.subheader(t("search_play"))
st.caption(t("search_play_cap"))

# Universo de jogadas de passe no contexto atual
plays_ctx = df_ctx[df_ctx["play_type"] == "passe/dropback"]

colf1, colf2, colf3 = st.columns(3)
with colf1:
    formacoes = [QUALQUER] + sorted(plays_ctx["offenseFormation"].dropna().unique().tolist())
    sel_form = st.selectbox(t("formation"), formacoes, key="busca_form")
with colf2:
    dropbacks = [QUALQUER] + sorted(plays_ctx["dropBackType"].dropna().unique().tolist())
    sel_drop = st.selectbox(t("dropback_type"), dropbacks, key="busca_drop")
with colf3:
    PA_SIM, PA_NAO = t("yes"), t("no")
    sel_pa = st.selectbox(t("playaction"), [QUALQUER, PA_SIM, PA_NAO], key="busca_pa")

busca = plays_ctx.copy()
if sel_form != QUALQUER:
    busca = busca[busca["offenseFormation"] == sel_form]
if sel_drop != QUALQUER:
    busca = busca[busca["dropBackType"] == sel_drop]
if sel_pa != QUALQUER:
    busca = busca[busca["pff_playAction"] == (1 if sel_pa == PA_SIM else 0)]

if busca.empty:
    st.warning(t("no_play_found"))
else:
    m1, m2, m3, m4, m5 = st.columns(5)
    m1.metric(t("plays"), f"{len(busca)}")
    m2.metric(t("avg_score"), f"{busca['play_score'].mean():.2f}")
    m3.metric(t("avg_yards_m"), f"{busca['playResult'].mean():.1f}")
    suc = busca["_success"].mean(skipna=True)
    m4.metric(t("success_rate"), f"{suc:.0%}" if pd.notna(suc) else "n/d")
    m5.metric(t("sack_rate"), f"{(busca['passResult'] == 'S').mean():.0%}")

    st.markdown(f"**{t('play_examples')}**")
    exemplos = (busca[["week", "possessionTeam", "defensiveTeam", "down",
                       "yardsToGo", "playResult", "playDescription"]]
                .rename(columns={
                    "week": t("col_week"), "possessionTeam": t("col_off"),
                    "defensiveTeam": t("col_def"), "down": t("down"),
                    "yardsToGo": "YTG", "playResult": t("col_yards"),
                    "playDescription": t("col_desc")})
                .head(15))
    st.dataframe(exemplos, use_container_width=True, hide_index=True)


# ---------------------------------------------------------------------------
# Painel de jogadores
# ---------------------------------------------------------------------------
st.divider()
st.subheader(t("players_panel"))

colA, colB = st.columns(2)

with colA:
    st.markdown(f"**{t('rush_threats')}**")
    st.caption(t("hover_hint"))
    top_rush = _col_perfil(
        pass_rush[pass_rush["jogadas"] >= 50]
        .sort_values("taxa_pressao", ascending=False).head(10)
    ).sort_values("taxa_pressao")

    fig_rush = px.bar(
        top_rush, x="taxa_pressao", y="displayName", orientation="h",
        color="taxa_pressao", color_continuous_scale=SCALE_RUSH,
        labels={"taxa_pressao": t("lbl_pressure_rate"), "displayName": ""},
        # customdata = dados que só aparecem no hover (não estão no eixo)
        custom_data=["officialPosition", "jogadas", "sacks", "hits", "hurries",
                     "_nasc", "_altura", "_peso", "_faculdade", "_foto"])
    fig_rush.update_traces(hovertemplate=(
        "<img src='%{customdata[9]}' width='70'><br>"
        "<b>%{y}</b> (%{customdata[0]})<br>"
        "Taxa de pressão: %{x:.1%}<br>"
        "Jogadas: %{customdata[1]}<br>"
        "Sacks: %{customdata[2]} · Hits: %{customdata[3]} · Hurries: %{customdata[4]}<br>"
        "<br><i>Perfil</i><br>"
        "Nascimento: %{customdata[5]}<br>"
        "Altura: %{customdata[6]} · Peso: %{customdata[7]}<br>"
        "Faculdade: %{customdata[8]}<extra></extra>"))
    fig_rush.update_layout(height=400, margin=dict(l=10, r=10, t=10, b=10),
                           coloraxis_showscale=False)
    st.plotly_chart(_estilo_plotly(fig_rush), use_container_width=True)

with colB:
    st.markdown(f"**{t('prot_reliable')}**")
    st.caption(t("hover_hint"))
    top_block = _col_perfil(
        protection[protection["jogadas"] >= 50]
        .sort_values("taxa_protecao", ascending=False).head(10)
    ).sort_values("taxa_protecao")

    fig_block = px.bar(
        top_block, x="taxa_protecao", y="displayName", orientation="h",
        color="taxa_protecao", color_continuous_scale=SCALE_PROT,
        labels={"taxa_protecao": t("lbl_clean_rate"), "displayName": ""},
        custom_data=["officialPosition", "jogadas", "sacks_permitidos",
                     "hits_permitidos", "hurries_permitidos",
                     "_nasc", "_altura", "_peso", "_faculdade", "_foto"])
    fig_block.update_traces(hovertemplate=(
        "<img src='%{customdata[9]}' width='70'><br>"
        "<b>%{y}</b> (%{customdata[0]})<br>"
        "Jogadas sem falha: %{x:.1%}<br>"
        "Jogadas: %{customdata[1]}<br>"
        "Permitidos — Sacks: %{customdata[2]} · Hits: %{customdata[3]} · "
        "Hurries: %{customdata[4]}<br>"
        "<br><i>Perfil</i><br>"
        "Nascimento: %{customdata[5]}<br>"
        "Altura: %{customdata[6]} · Peso: %{customdata[7]}<br>"
        "Faculdade: %{customdata[8]}<extra></extra>"))
    fig_block.update_layout(height=400, margin=dict(l=10, r=10, t=10, b=10),
                            coloraxis_showscale=False)
    st.plotly_chart(_estilo_plotly(fig_block), use_container_width=True)


# ---------------------------------------------------------------------------
# Barra de pesquisa de JOGADORES
# ---------------------------------------------------------------------------
st.divider()
st.subheader(t("search_player"))

# Lista única de nomes (união das duas tabelas), ordenada
nomes = sorted(set(pass_rush["displayName"].dropna())
               | set(protection["displayName"].dropna()))

SELECIONE = t("select_ph")
sel_jogador = st.selectbox(
    t("pick_player"),
    options=[SELECIONE] + nomes,
    help=t("pick_help"))

if sel_jogador != SELECIONE:
    achou = False

    linha_rush = pass_rush[pass_rush["displayName"] == sel_jogador]
    linha_block = protection[protection["displayName"] == sel_jogador]

    # Perfil (pega de qualquer uma das tabelas)
    fonte = linha_rush if not linha_rush.empty else linha_block
    if not fonte.empty:
        p = _col_perfil(fonte).iloc[0]
        cfoto, cinfo = st.columns([1, 4])
        with cfoto:
            st.image(foto_de(sel_jogador), width=120)
        with cinfo:
            st.markdown(f"### {sel_jogador}  ·  {p['officialPosition']}")
            c1, c2, c3, c4 = st.columns(4)
            c1.metric(t("birth_age"), p["_nasc"])
            c2.metric(t("height"), p["_altura"])
            c3.metric(t("weight"), p["_peso"])
            c4.metric(t("college"), p["_faculdade"])

    def _cartao_estrelas(ratings_df, atributos, titulo, cor_radar):
        """Mostra o rating em estrelas (5 características) + radar, para o jogador."""
        linha = ratings_df[ratings_df["displayName"] == sel_jogador]
        if linha.empty:
            return
        r = linha.iloc[0]
        st.markdown(f"#### {titulo}")
        st.caption(t("rating_cap"))

        rotulos = [attr_label(a, LANG) for a in atributos]
        cestrelas, cradar = st.columns([1, 1])
        with cestrelas:
            for attr, rot in zip(atributos, rotulos):
                nota = r[attr]
                desc = DESC_ATRIBUTOS.get(attr, "")
                st.markdown(
                    f"<div style='font-size:1.02rem;margin:2px 0' title=\"{desc}\">"
                    f"<span style='color:#A5ACAF;border-bottom:1px dotted #A5ACAF88;"
                    f"cursor:help'>{rot}</span> "
                    f"<span style='color:#7f8a90;font-size:0.85rem'>&#9432;</span><br>"
                    f"<span style='color:#F2C14E;font-size:1.25rem'>{_estrelas_txt(nota)}</span>"
                    f"<span style='color:#A5ACAF'> &nbsp;{nota:.1f}/5</span>"
                    f"</div>", unsafe_allow_html=True)
        with cradar:
            valores = [float(r[a]) for a in atributos]
            fig = px.line_polar(
                r=valores + [valores[0]],
                theta=rotulos + [rotulos[0]],
                line_close=True, range_r=[0, 5])
            fig.update_traces(fill="toself", line_color=cor_radar,
                              fillcolor=cor_radar, opacity=0.55)
            fig.update_layout(height=300, margin=dict(l=30, r=30, t=20, b=20),
                              polar=dict(bgcolor="rgba(0,0,0,0)",
                                         radialaxis=dict(gridcolor="#A5ACAF33",
                                                         range=[0, 5])))
            st.plotly_chart(_estilo_plotly(fig), use_container_width=True)

    if not linha_rush.empty:
        achou = True
        r = linha_rush.iloc[0]
        _cartao_estrelas(ratings_rush, ATRIBUTOS_RUSH,
                         t("eval_rusher"), "#D50A0A")
        with st.expander(t("raw_rush")):
            d1, d2, d3, d4, d5 = st.columns(5)
            d1.metric(t("plays"), int(r["jogadas"]))
            d2.metric(t("lbl_pressure_rate"), f"{r['taxa_pressao']:.1%}")
            d3.metric(t("sacks"), int(r["sacks"]))
            d4.metric(t("hits"), int(r["hits"]))
            d5.metric(t("hurries"), int(r["hurries"]))

    if not linha_block.empty:
        achou = True
        b = linha_block.iloc[0]
        _cartao_estrelas(ratings_prot, ATRIBUTOS_PROT,
                         t("eval_blocker"), "#2E6FB0")
        with st.expander(t("raw_prot")):
            e1, e2, e3, e4, e5 = st.columns(5)
            e1.metric(t("plays"), int(b["jogadas"]))
            e2.metric(t("clean_plays_m"), f"{b['taxa_protecao']:.1%}")
            e3.metric(t("sacks_allowed"), int(b["sacks_permitidos"]))
            e4.metric(t("hits_allowed"), int(b["hits_permitidos"]))
            e5.metric(t("hurries_allowed"), int(b["hurries_permitidos"]))

    # Jogador existe nas tabelas de efetividade mas com poucas jogadas
    # (abaixo do mínimo para rating) -> ainda mostra números crus, sem estrelas.
    if not achou:
        st.info(t("no_player_stats"))
    elif (linha_rush.empty or ratings_rush.empty or
          sel_jogador not in set(ratings_rush.get("displayName", []))) and \
         (linha_block.empty or ratings_prot.empty or
          sel_jogador not in set(ratings_prot.get("displayName", []))):
        st.caption(t("small_sample"))


# ---------------------------------------------------------------------------
# Campo interativo: clique numa posição para ver os principais jogadores
# ---------------------------------------------------------------------------
st.divider()
st.subheader(t("field_title"))
st.caption(t("field_cap"))

# Layout aproximado de posições numa formação (x = largura 0-100, y = 0-100).
# Ataque (metade de baixo) e defesa (metade de cima), separados pela linha de scrimmage (y=50).
POSICOES_CAMPO = {
    # --- ATAQUE (offense) ---
    "QB":  (50, 30, "ATA"), "RB": (50, 20, "ATA"), "FB": (42, 22, "ATA"),
    "C":   (50, 42, "ATA"), "G":  (44, 42, "ATA"), "T":  (36, 42, "ATA"),
    "TE":  (60, 42, "ATA"), "WR": (14, 44, "ATA"),
    # --- DEFESA (defense) ---
    "DE":  (38, 58, "DEF"), "DT": (46, 58, "DEF"), "NT": (52, 58, "DEF"),
    "OLB": (32, 66, "DEF"), "ILB": (48, 66, "DEF"), "MLB": (56, 66, "DEF"),
    "CB":  (16, 62, "DEF"), "SS":  (40, 80, "DEF"), "FS":  (60, 80, "DEF"),
}

COR_ATA = "#5B8FD6"   # azul (ataque)
COR_DEF = "#C96A6A"   # vermelho suave (defesa)

fig_campo = go.Figure()

# Gramado
fig_campo.add_shape(type="rect", x0=0, y0=0, x1=100, y1=100,
                    fillcolor="#0B6623", line=dict(color="#0B6623"), layer="below")
# Linhas de jarda horizontais
for y in range(10, 100, 10):
    fig_campo.add_shape(type="line", x0=0, y0=y, x1=100, y1=y,
                        line=dict(color="#FFFFFF", width=1), layer="below",
                        opacity=0.35)
# Linha de scrimmage (destaque)
fig_campo.add_shape(type="line", x0=0, y0=50, x1=100, y1=50,
                    line=dict(color="#F2C14E", width=2, dash="dot"), layer="below")

# Pontos das posições
xs, ys, textos, cores, custom = [], [], [], [], []
for pos, (x, y, lado) in POSICOES_CAMPO.items():
    xs.append(x); ys.append(y); textos.append(pos)
    cores.append(COR_ATA if lado == "ATA" else COR_DEF)
    custom.append(pos)

fig_campo.add_trace(go.Scatter(
    x=xs, y=ys, mode="markers+text", text=textos,
    textposition="middle center",
    textfont=dict(color="#FFFFFF", size=11, family="Arial Black"),
    marker=dict(size=34, color=cores, line=dict(color="#FFFFFF", width=2)),
    customdata=custom,
    hovertemplate="<b>%{customdata}</b><br>" + t("field_click_hint") + "<extra></extra>",
))

fig_campo.update_xaxes(visible=False, range=[0, 100])
fig_campo.update_yaxes(visible=False, range=[0, 100])
fig_campo.update_layout(
    height=520, margin=dict(l=10, r=10, t=30, b=10),
    paper_bgcolor="rgba(0,0,0,0)", plot_bgcolor="rgba(0,0,0,0)",
    showlegend=False,
    annotations=[
        dict(x=2, y=48, text=t("offense"), showarrow=False, xanchor="left",
             font=dict(color=COR_ATA, size=13)),
        dict(x=2, y=52, text=t("defense"), showarrow=False, xanchor="left",
             font=dict(color=COR_DEF, size=13)),
    ])

evento = st.plotly_chart(fig_campo, use_container_width=True,
                         on_select="rerun", key="campo")

# Captura a posição clicada
pos_sel = None
try:
    pts = evento["selection"]["points"] if evento else None
    if pts:
        pos_sel = pts[0].get("customdata")
        if isinstance(pos_sel, list):
            pos_sel = pos_sel[0]
except (KeyError, TypeError, IndexError):
    pos_sel = None

if pos_sel:
    tabela_pos, tipo = principais_por_posicao(pos_sel, topn=8)
    st.markdown(f"### {t('top_players')} — {pos_sel}")
    if tabela_pos is None or tabela_pos.empty:
        st.info(t("no_pos_metrics", pos=pos_sel))
    else:
        label = t("metric_pressure") if tipo == "rush" else t("metric_reliability")
        unidade = t("unit_pressure") if tipo == "rush" else t("unit_clean")
        st.caption(f"{t('ordered_by')}: {label}")
        # cartões com foto + nome + métrica
        cols = st.columns(4)
        for i, (_, row) in enumerate(tabela_pos.iterrows()):
            with cols[i % 4]:
                st.image(foto_de(row["displayName"]), width=90)
                st.markdown(f"**{row['displayName']}**")
                st.caption(f"{row['valor']}{unidade} · "
                           f"{int(row['jogadas'])} {t('unit_plays')}")
else:
    st.caption(t("no_pos_selected"))
