"""
recommender.py - Motor de recomendação de jogada para o treinador.
===================================================================

Dada uma situação de jogo (down, jardas para o first down, região do campo
e, opcionalmente, a cobertura que a defesa mostra), busca no histórico as
jogadas mais parecidas e ranqueia as combinações de:

    offenseFormation  x  dropBackType  x  pff_playAction

pela efetividade média (play_score), mostrando também taxa de sucesso,
jardas médias, e taxa de sack/interceptação para o treinador pesar o risco.

Filosofia: não inventa jogada. Mostra o que, historicamente, deu mais
resultado em situações equivalentes, com amostra suficiente para confiar.
"""

import pandas as pd

from data_prep import load_raw, prepare_plays


MIN_AMOSTRA = 8  # nº mínimo de jogadas para uma combinação ser recomendável


class PlayRecommender:
    def __init__(self, plays_prepared: pd.DataFrame):
        self.plays = plays_prepared

    # -----------------------------------------------------------------
    def _filtrar_situacao(self, down=None, dist_bucket=None,
                          field_bucket=None, coverage=None):
        """Filtra jogadas semelhantes à situação informada."""
        df = self.plays
        # Só faz sentido recomendar entre jogadas de passe/dropback,
        # que são as descritas por este dataset.
        df = df[df["play_type"] == "passe/dropback"]

        if down is not None:
            df = df[df["down"] == down]
        if dist_bucket is not None:
            df = df[df["dist_bucket"] == dist_bucket]
        if field_bucket is not None:
            df = df[df["field_bucket"] == field_bucket]
        if coverage is not None:
            df = df[df["pff_passCoverage"] == coverage]
        return df

    # -----------------------------------------------------------------
    def recomendar(self, down=None, dist_bucket=None, field_bucket=None,
                   coverage=None, top=5, min_amostra=MIN_AMOSTRA):
        """
        Retorna um DataFrame ranqueado de combinações de jogada para a
        situação. Se o filtro ficar restrito demais, afrouxa a região do
        campo e depois a cobertura, para sempre ter uma resposta útil.
        """
        niveis = [
            dict(down=down, dist_bucket=dist_bucket, field_bucket=field_bucket, coverage=coverage),
            dict(down=down, dist_bucket=dist_bucket, field_bucket=None, coverage=coverage),
            dict(down=down, dist_bucket=dist_bucket, field_bucket=None, coverage=None),
            dict(down=down, dist_bucket=None, field_bucket=None, coverage=None),
        ]

        for i, filtro in enumerate(niveis):
            df = self._filtrar_situacao(**filtro)
            if len(df) >= min_amostra:
                nota = self._nivel_desc(i, filtro)
                return self._ranquear(df, top, min_amostra), nota, len(df)

        # Nada suficiente encontrado
        return pd.DataFrame(), "sem amostra suficiente", 0

    # -----------------------------------------------------------------
    def _ranquear(self, df, top, min_amostra):
        grp = (
            df.groupby(["offenseFormation", "dropBackType", "pff_playAction"])
            .agg(
                jogadas=("play_score", "count"),
                score_medio=("play_score", "mean"),
                jardas_media=("playResult", "mean"),
                taxa_sucesso=("_success", "mean"),
                taxa_sack=("passResult", lambda s: (s == "S").mean()),
                taxa_int=("passResult", lambda s: (s == "IN").mean()),
            )
            .reset_index()
        )
        grp = grp[grp["jogadas"] >= min_amostra]
        for c in ["score_medio", "jardas_media", "taxa_sucesso", "taxa_sack", "taxa_int"]:
            grp[c] = grp[c].round(3)
        grp["playAction"] = grp["pff_playAction"].map({1: "sim", 0: "nao"})
        grp = grp.drop(columns=["pff_playAction"])
        return grp.sort_values("score_medio", ascending=False).head(top)

    # -----------------------------------------------------------------
    @staticmethod
    def _nivel_desc(i, filtro):
        descr = {
            0: "situação exata (down + distância + campo + cobertura)",
            1: "afrouxado: ignorando região do campo",
            2: "afrouxado: ignorando campo e cobertura",
            3: "afrouxado: apenas o down",
        }
        return descr.get(i, "desconhecido")

    # -----------------------------------------------------------------
    def melhores_contra_cobertura(self, coverage, top=5, min_amostra=MIN_AMOSTRA):
        """
        Ataque geral: o que funciona melhor contra uma cobertura específica.
        Retorna (tabela_ranqueada, total_de_jogadas_analisadas).
        """
        df = self.plays[
            (self.plays["play_type"] == "passe/dropback")
            & (self.plays["pff_passCoverage"] == coverage)
        ]
        return self._ranquear(df, top, min_amostra), len(df)


def build_recommender():
    plays, _pff, _players = load_raw()
    dfp = prepare_plays(plays)
    return PlayRecommender(dfp)


if __name__ == "__main__":
    rec = build_recommender()
    tabela, nota, n = rec.recomendar(down=3, dist_bucket="longa (8+)", top=5)
    print(f"Base usada: {nota} ({n} jogadas)")
    print(tabela.to_string(index=False))
