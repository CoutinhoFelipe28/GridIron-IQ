"""
coach_cli.py - Assistente de decisão de jogada para o treinador.
================================================================

Uso:
  py coach_cli.py --down 3 --ytg 8
  py coach_cli.py --down 1 --ytg 10 --yardline 15 --coverage Cover-3
  py coach_cli.py --coverage Cover-2 --somente-cobertura
  py coach_cli.py --jogadores            (só o painel de jogadores)

Parâmetros:
  --down       Descida (1-4)
  --ytg        Jardas para o first down (yards to go)
  --yardline   absoluteYardlineNumber (distância até a end zone de ataque).
               Menor = mais perto de pontuar. Opcional.
  --coverage   Cobertura mostrada pela defesa (ex.: Cover-1, Cover-3...). Opcional.
  --top        Quantas jogadas listar (padrão 5)
  --somente-cobertura   Ignora a situação e mostra o que funciona vs a cobertura
  --jogadores  Mostra apenas o painel de efetividade de jogadores
"""

import argparse

from data_prep import _distance_bucket, _field_bucket
from recommender import build_recommender
from players_layer import build_players_layer


def _fmt_pct(v):
    return f"{v:.0%}" if v == v else "-"  # v==v filtra NaN


def imprimir_recomendacao(tabela, nota, n, situacao_txt):
    print("=" * 72)
    print("RECOMENDAÇÃO DE JOGADA")
    print("=" * 72)
    print(f"Situação: {situacao_txt}")
    print(f"Base histórica: {nota}  |  {n} jogadas analisadas")
    print("-" * 72)
    if tabela.empty:
        print("Sem amostra suficiente para recomendar com confiança.")
        return
    print(f"{'#':<3}{'Formação':<12}{'Dropback':<16}{'PlayAct':<8}"
          f"{'N':<5}{'Score':<8}{'Jardas':<8}{'Suc%':<7}{'Sack%':<7}{'INT%':<6}")
    for i, (_, r) in enumerate(tabela.iterrows(), start=1):
        print(f"{i:<3}{str(r['offenseFormation']):<12}{str(r['dropBackType']):<16}"
              f"{str(r['playAction']):<8}{int(r['jogadas']):<5}"
              f"{r['score_medio']:<8.2f}{r['jardas_media']:<8.2f}"
              f"{_fmt_pct(r['taxa_sucesso']):<7}{_fmt_pct(r['taxa_sack']):<7}"
              f"{_fmt_pct(r['taxa_int']):<6}")
    print("-" * 72)
    melhor = tabela.iloc[0]
    print(f"SUGESTÃO: formação {melhor['offenseFormation']} com dropback "
          f"{melhor['dropBackType']} (play-action: {melhor['playAction']}).")
    print(f"  -> {melhor['jardas_media']:.1f} jardas médias, "
          f"{_fmt_pct(melhor['taxa_sucesso'])} de sucesso, "
          f"risco de sack {_fmt_pct(melhor['taxa_sack'])}.")


def imprimir_jogadores(layer, top, perfil=False):
    print()
    print("=" * 72)
    print("PAINEL DE JOGADORES (fator humano)")
    print("=" * 72)
    print(layer.resumo_para_decisao(top=top, perfil=perfil))


def main():
    p = argparse.ArgumentParser(description="Assistente de decisão de jogada.")
    p.add_argument("--down", type=int, choices=[1, 2, 3, 4])
    p.add_argument("--ytg", type=int, help="jardas para o first down")
    p.add_argument("--yardline", type=int, help="absoluteYardlineNumber (opcional)")
    p.add_argument("--coverage", type=str, help="cobertura da defesa (opcional)")
    p.add_argument("--top", type=int, default=5)
    p.add_argument("--somente-cobertura", action="store_true",
                   dest="somente_cobertura")
    p.add_argument("--jogadores", action="store_true")
    p.add_argument("--perfil", action="store_true",
                   help="inclui perfil do jogador (nascimento/idade, altura, "
                        "peso, faculdade)")
    args = p.parse_args()

    # Painel de jogadores isolado
    if args.jogadores:
        layer = build_players_layer()
        imprimir_jogadores(layer, args.top, perfil=args.perfil)
        return

    rec = build_recommender()

    # Modo: só contra a cobertura
    if args.somente_cobertura:
        if not args.coverage:
            print("Erro: --somente-cobertura exige --coverage.")
            return
        tabela, n = rec.melhores_contra_cobertura(args.coverage, top=args.top)
        imprimir_recomendacao(
            tabela, f"todas as jogadas vs {args.coverage}", n,
            f"Melhor ataque contra {args.coverage}")
        return

    # Modo situação de jogo
    if args.down is None or args.ytg is None:
        print("Erro: informe pelo menos --down e --ytg (ou use --jogadores / "
              "--somente-cobertura). Use -h para ajuda.")
        return

    dist_bucket = _distance_bucket(args.ytg)
    field_bucket = _field_bucket(args.yardline) if args.yardline is not None else None

    situacao_txt = f"{args.down}º down, {args.ytg} jardas ({dist_bucket})"
    if field_bucket:
        situacao_txt += f", {field_bucket}"
    if args.coverage:
        situacao_txt += f", defesa em {args.coverage}"

    tabela, nota, n = rec.recomendar(
        down=args.down, dist_bucket=dist_bucket,
        field_bucket=field_bucket, coverage=args.coverage, top=args.top)
    imprimir_recomendacao(tabela, nota, n, situacao_txt)

    # Complementa com o painel de jogadores
    layer = build_players_layer()
    imprimir_jogadores(layer, top=3, perfil=args.perfil)


if __name__ == "__main__":
    main()
