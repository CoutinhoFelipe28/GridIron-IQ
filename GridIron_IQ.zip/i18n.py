"""
i18n.py - Traduções da interface (PT-BR e EN-US).
=================================================

Uso:
    from i18n import make_translator
    t = make_translator(lang)   # lang em {"pt", "en"}
    st.title(t("app_title"))

Se uma chave não existir no idioma escolhido, cai no PT-BR e, por fim, na
própria chave (para não quebrar a interface).
"""

TRANSLATIONS = {
    # ---- Cabeçalho ----
    "app_title": {"pt": "🏈 GridIron IQ",
                  "en": "🏈 GridIron IQ"},
    "app_subtitle": {
        "pt": "Inteligência de jogo para treinadores — decisão de jogada e "
              "efetividade de jogadores.",
        "en": "Game intelligence for coaches — play calling and player "
              "effectiveness."},
    "app_caption": {
        "pt": "Baseado no histórico NFL Big Data Bowl 2021 (Semanas 1-8). "
              "As métricas são descritivas: mostram o que funcionou, não uma previsão.",
        "en": "Based on the NFL Big Data Bowl 2021 dataset (Weeks 1-8). "
              "Metrics are descriptive: they show what worked, not a prediction."},
    "language": {"pt": "Idioma", "en": "Language"},

    # ---- Barra lateral ----
    "sidebar_context": {"pt": "Filtros de contexto", "en": "Context filters"},
    "weeks": {"pt": "Semana(s)", "en": "Week(s)"},
    "off_team": {"pt": "Time no ataque (opcional)", "en": "Offensive team (optional)"},
    "all": {"pt": "(todos)", "en": "(all)"},
    "sidebar_situation": {"pt": "Situação de jogo", "en": "Game situation"},
    "down": {"pt": "Down", "en": "Down"},
    "ytg": {"pt": "Jardas para o first down", "en": "Yards to first down"},
    "filter_field": {"pt": "Filtrar por região do campo", "en": "Filter by field region"},
    "yardline": {"pt": "Yardline (dist. até a end zone)",
                 "en": "Yardline (dist. to end zone)"},
    "coverage": {"pt": "Cobertura da defesa", "en": "Defensive coverage"},
    "any": {"pt": "(qualquer)", "en": "(any)"},
    "how_many": {"pt": "Quantas jogadas listar", "en": "How many plays to list"},

    # ---- Recomendação ----
    "recommended_plays": {"pt": "Jogadas recomendadas", "en": "Recommended plays"},
    "situation": {"pt": "Situação", "en": "Situation"},
    "hist_base": {"pt": "Base histórica", "en": "Historical base"},
    "plays_analyzed": {"pt": "jogadas analisadas", "en": "plays analyzed"},
    "no_sample": {"pt": "Sem amostra suficiente para recomendar com confiança nesta situação.",
                  "en": "Not enough sample to recommend confidently for this situation."},
    "suggestion": {"pt": "Sugestão", "en": "Suggestion"},
    "avg_yards": {"pt": "jardas médias", "en": "avg yards"},
    "success_of": {"pt": "de sucesso", "en": "success"},
    "sack_risk": {"pt": "risco de sack", "en": "sack risk"},
    "chart_effectiveness": {"pt": "Efetividade por jogada", "en": "Effectiveness by play"},

    # ---- Colunas / rótulos de gráfico ----
    "col_formation": {"pt": "Formação", "en": "Formation"},
    "col_dropback": {"pt": "Dropback", "en": "Dropback"},
    "col_playact": {"pt": "PlayAct", "en": "PlayAct"},
    "col_n": {"pt": "N", "en": "N"},
    "col_score": {"pt": "Score", "en": "Score"},
    "col_yards": {"pt": "Jardas", "en": "Yards"},
    "col_suc": {"pt": "Suc%", "en": "Succ%"},
    "col_sack": {"pt": "Sack%", "en": "Sack%"},
    "col_int": {"pt": "INT%", "en": "INT%"},
    "lbl_score": {"pt": "Score de efetividade", "en": "Effectiveness score"},
    "lbl_success": {"pt": "Sucesso", "en": "Success"},
    "lbl_pressure_rate": {"pt": "Taxa de pressão", "en": "Pressure rate"},
    "lbl_clean_rate": {"pt": "Jogadas sem falha", "en": "Clean plays"},

    # ---- Busca de jogada ----
    "search_play": {"pt": "🔎 Pesquisar jogada", "en": "🔎 Search play"},
    "search_play_cap": {
        "pt": "Busque ou selecione uma combinação específica de jogada e veja o "
              "desempenho dela no contexto filtrado (semana/time).",
        "en": "Search or pick a specific play combination and see its "
              "performance within the filtered context (week/team)."},
    "formation": {"pt": "Formação", "en": "Formation"},
    "dropback_type": {"pt": "Tipo de dropback", "en": "Dropback type"},
    "playaction": {"pt": "Play-action", "en": "Play-action"},
    "yes": {"pt": "sim", "en": "yes"},
    "no": {"pt": "nao", "en": "no"},
    "no_play_found": {"pt": "Nenhuma jogada encontrada com esses filtros no contexto atual.",
                      "en": "No plays found with these filters in the current context."},
    "plays": {"pt": "Jogadas", "en": "Plays"},
    "avg_score": {"pt": "Score médio", "en": "Avg score"},
    "avg_yards_m": {"pt": "Jardas médias", "en": "Avg yards"},
    "success_rate": {"pt": "Taxa de sucesso", "en": "Success rate"},
    "sack_rate": {"pt": "Taxa de sack", "en": "Sack rate"},
    "play_examples": {"pt": "Exemplos de jogadas (descrição real do dataset)",
                      "en": "Play examples (real description from the dataset)"},
    "col_week": {"pt": "Sem", "en": "Wk"},
    "col_off": {"pt": "Ataque", "en": "Offense"},
    "col_def": {"pt": "Defesa", "en": "Defense"},
    "col_desc": {"pt": "Descrição", "en": "Description"},

    # ---- Painel de jogadores ----
    "players_panel": {"pt": "Painel de jogadores (fator humano)",
                      "en": "Players panel (human factor)"},
    "rush_threats": {"pt": "Ameaças de pass rush (reforçar proteção)",
                     "en": "Pass rush threats (reinforce protection)"},
    "prot_reliable": {"pt": "Proteção mais confiável (lado seguro)",
                      "en": "Most reliable protection (safe side)"},
    "hover_hint": {"pt": "Passe o mouse sobre a barra do jogador para ver o perfil completo.",
                   "en": "Hover over the player's bar to see the full profile."},

    # ---- Busca de jogador ----
    "search_player": {"pt": "🔎 Pesquisar jogador", "en": "🔎 Search player"},
    "pick_player": {"pt": "Digite ou selecione o jogador",
                    "en": "Type or select the player"},
    "select_ph": {"pt": "(selecione)", "en": "(select)"},
    "pick_help": {"pt": "A caixa aceita digitação para filtrar os nomes.",
                  "en": "The box accepts typing to filter names."},
    "birth_age": {"pt": "Nascimento / idade", "en": "Birth / age"},
    "height": {"pt": "Altura", "en": "Height"},
    "weight": {"pt": "Peso", "en": "Weight"},
    "college": {"pt": "Faculdade", "en": "College"},
    "eval_rusher": {"pt": "Avaliação como pass rusher (defesa)",
                    "en": "Rating as pass rusher (defense)"},
    "eval_blocker": {"pt": "Avaliação como bloqueador (proteção)",
                     "en": "Rating as blocker (protection)"},
    "rating_cap": {"pt": "Avaliação relativa aos jogadores da mesma função "
                         "(percentil no dataset). 5★ = elite do grupo.",
                   "en": "Rating relative to players in the same role "
                         "(percentile in the dataset). 5★ = elite of the group."},
    "raw_rush": {"pt": "Números crus (pass rush)", "en": "Raw numbers (pass rush)"},
    "raw_prot": {"pt": "Números crus (proteção)", "en": "Raw numbers (protection)"},
    "sacks": {"pt": "Sacks", "en": "Sacks"},
    "hits": {"pt": "Hits", "en": "Hits"},
    "hurries": {"pt": "Hurries", "en": "Hurries"},
    "sacks_allowed": {"pt": "Sacks permitidos", "en": "Sacks allowed"},
    "hits_allowed": {"pt": "Hits permitidos", "en": "Hits allowed"},
    "hurries_allowed": {"pt": "Hurries permitidos", "en": "Hurries allowed"},
    "clean_plays_m": {"pt": "Jogadas sem falha", "en": "Clean plays"},
    "no_player_stats": {"pt": "Jogador sem estatísticas de pass rush ou proteção no dataset.",
                        "en": "Player has no pass rush or protection stats in the dataset."},
    "small_sample": {"pt": "Amostra pequena: rating em estrelas não calculado "
                          "(exige um mínimo de jogadas). Veja os números crus acima.",
                     "en": "Small sample: star rating not computed "
                          "(requires a minimum of plays). See the raw numbers above."},

    # ---- Campo interativo ----
    "field_title": {"pt": "🏟️ Campo interativo por posição",
                    "en": "🏟️ Interactive field by position"},
    "field_cap": {"pt": "Clique em uma posição no campo para ver os principais "
                        "jogadores que atuam nela. Azul = ataque · Vermelho = defesa.",
                  "en": "Click a position on the field to see the top players "
                        "who play it. Blue = offense · Red = defense."},
    "offense": {"pt": "ATAQUE", "en": "OFFENSE"},
    "defense": {"pt": "DEFESA", "en": "DEFENSE"},
    "field_click_hint": {"pt": "clique para ver os jogadores",
                         "en": "click to see the players"},
    "top_players": {"pt": "Principais jogadores", "en": "Top players"},
    "no_pos_metrics": {
        "pt": "Não há métricas de efetividade suficientes para a posição {pos} "
              "neste dataset (foco em pass rush e proteção).",
        "en": "Not enough effectiveness metrics for position {pos} in this "
              "dataset (focused on pass rush and protection)."},
    "ordered_by": {"pt": "Ordenados por", "en": "Ordered by"},
    "no_pos_selected": {"pt": "Nenhuma posição selecionada ainda.",
                        "en": "No position selected yet."},
    "metric_pressure": {"pt": "Pressão ao QB", "en": "Pressure on QB"},
    "metric_reliability": {"pt": "Confiabilidade na proteção",
                           "en": "Protection reliability"},
    "unit_pressure": {"pt": "% pressão", "en": "% pressure"},
    "unit_clean": {"pt": "% sem falha", "en": "% clean"},
    "unit_plays": {"pt": "jogadas", "en": "plays"},

    # ---- Buckets de situação (distância / campo) ----
    "dist_curta (1-3)": {"pt": "curta (1-3)", "en": "short (1-3)"},
    "dist_media (4-7)": {"pt": "media (4-7)", "en": "medium (4-7)"},
    "dist_longa (8+)": {"pt": "longa (8+)", "en": "long (8+)"},
}

# Atributos das estrelas (rótulos) por idioma
ATTR_LABELS = {
    "Pressão": {"pt": "Pressão", "en": "Pressure"},
    "Finalização (sack)": {"pt": "Finalização (sack)", "en": "Finishing (sack)"},
    "Impacto (hit)": {"pt": "Impacto (hit)", "en": "Impact (hit)"},
    "Perturbação (hurry)": {"pt": "Perturbação (hurry)", "en": "Disruption (hurry)"},
    "Volume/Durabilidade": {"pt": "Volume/Durabilidade", "en": "Volume/Durability"},
    "Confiabilidade": {"pt": "Confiabilidade", "en": "Reliability"},
    "Proteção de sack": {"pt": "Proteção de sack", "en": "Sack protection"},
    "Proteção de hit": {"pt": "Proteção de hit", "en": "Hit protection"},
    "Proteção de hurry": {"pt": "Proteção de hurry", "en": "Hurry protection"},
}


def make_translator(lang):
    """Retorna uma função t(chave, **fmt) para o idioma escolhido."""
    lang = "en" if str(lang).lower().startswith("en") else "pt"

    def t(chave, **fmt):
        entry = TRANSLATIONS.get(chave)
        if entry is None:
            texto = chave
        else:
            texto = entry.get(lang) or entry.get("pt") or chave
        return texto.format(**fmt) if fmt else texto

    return t


def attr_label(attr, lang):
    """Rótulo traduzido de um atributo de estrela (mantém a chave interna)."""
    lang = "en" if str(lang).lower().startswith("en") else "pt"
    entry = ATTR_LABELS.get(attr)
    return (entry.get(lang) if entry else None) or attr
