"""
build_headshots.py - Gera o mapeamento nome -> URL de headshot (media day).
===========================================================================

Baixa o roster 2021 da nflverse (dados públicos) e cruza com os jogadores do
nosso players.csv pelo nome, salvando um CSV local `headshots.csv` com:
    nflId, displayName, headshot_url

Assim o dashboard carrega as fotos rápido e offline (sem rebaixar o roster).

Rodar uma vez (precisa de internet):
    py build_headshots.py

Fonte das imagens: headshots oficiais da NFL, servidos via nflverse
(https://github.com/nflverse/nflverse-data). Uso apenas para exibição no
painel; os direitos das imagens são da NFL/nflverse.
"""

from pathlib import Path
import pandas as pd

from data_prep import load_raw

ROSTER_URL = ("https://github.com/nflverse/nflverse-data/releases/download/"
              "rosters/roster_2021.csv")
OUT = Path(__file__).resolve().parent / "headshots.csv"


def _norm(nome):
    """Normaliza nome para casar: minúsculas, sem pontuação/sufixos comuns."""
    if pd.isna(nome):
        return ""
    s = str(nome).lower().strip()
    for ch in [".", ",", "'", "-"]:
        s = s.replace(ch, " ")
    for suf in [" jr", " sr", " ii", " iii", " iv", " v"]:
        if s.endswith(suf):
            s = s[: -len(suf)]
    return " ".join(s.split())


def main():
    _plays, _pff, players = load_raw()
    players = players[["nflId", "displayName"]].copy()
    players["_key"] = players["displayName"].apply(_norm)

    roster = pd.read_csv(ROSTER_URL)
    roster = roster[["full_name", "headshot_url"]].dropna(subset=["full_name"])
    roster["_key"] = roster["full_name"].apply(_norm)
    # remove duplicatas de nome, mantendo a primeira URL
    roster = roster.drop_duplicates(subset=["_key"])

    merged = players.merge(roster[["_key", "headshot_url"]], on="_key", how="left")
    out = merged[["nflId", "displayName", "headshot_url"]]
    out.to_csv(OUT, index=False)

    total = len(out)
    com_foto = out["headshot_url"].notna().sum()
    print(f"Salvo em: {OUT}")
    print(f"Jogadores: {total} | com foto: {com_foto} "
          f"({com_foto/total:.0%}) | sem foto: {total - com_foto}")


if __name__ == "__main__":
    main()
