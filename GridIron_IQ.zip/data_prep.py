"""
data_prep.py - Carregamento e preparação dos dados para decisão de jogada.
==========================================================================

Prepara o plays.csv adicionando:
  - Bucket de campo (situação de campo: perto da própria end zone, meio, red zone)
  - Bucket de distância (curta / média / longa) a partir de yardsToGo
  - Indicador de sucesso da jogada (converteu o suficiente para a situação)
  - Métrica de efetividade da jogada (play_epa_like), combinando jardas,
    sucesso, completude e penalizações por sack/interceptação.

Também prepara métricas de efetividade individual de jogadores
(pass rush e proteção) juntando pffScoutingData + players.

Chaves de junção:
  plays  <-> pffScouting : gameId + playId
  players <-> pffScouting : nflId
"""

from pathlib import Path
import pandas as pd

BASE_DIR = Path(__file__).resolve().parent.parent
DATA_DIR = BASE_DIR / "extracted" / "nfl-big-data-bowl-regional-event-data-main" / "data"

PLAYS_CSV = DATA_DIR / "plays.csv"
PFF_CSV = DATA_DIR / "pffScoutingData.csv"
PLAYERS_CSV = DATA_DIR / "players.csv"
GAMES_CSV = DATA_DIR / "games.csv"


# ---------------------------------------------------------------------------
# Carregamento bruto
# ---------------------------------------------------------------------------
def load_raw():
    plays = pd.read_csv(PLAYS_CSV)
    pff = pd.read_csv(PFF_CSV)
    players = pd.read_csv(PLAYERS_CSV)
    return plays, pff, players


def load_games():
    """Carrega games.csv (usado para filtrar por semana/time)."""
    return pd.read_csv(GAMES_CSV)


def add_game_context(plays):
    """
    Junta week + times ao DataFrame de jogadas, para permitir filtro por
    semana e por time. Junção por gameId.
    """
    games = load_games()[["gameId", "week", "homeTeamAbbr", "visitorTeamAbbr"]]
    return plays.merge(games, on="gameId", how="left")


# ---------------------------------------------------------------------------
# Buckets de situação
# ---------------------------------------------------------------------------
def _distance_bucket(yards_to_go):
    """Classifica a distância para o first down."""
    if yards_to_go <= 3:
        return "curta (1-3)"
    if yards_to_go <= 7:
        return "media (4-7)"
    return "longa (8+)"


def _field_bucket(absolute_yardline):
    """
    Classifica a região do campo a partir de absoluteYardlineNumber
    (0-100+, distância até a end zone de ataque). Valores menores = mais
    perto de pontuar (red zone).
    """
    if pd.isna(absolute_yardline):
        return "desconhecido"
    if absolute_yardline <= 20:
        return "red zone (<=20)"
    if absolute_yardline <= 50:
        return "campo ofensivo (21-50)"
    if absolute_yardline <= 80:
        return "campo defensivo (51-80)"
    return "propria end zone (81+)"


def _play_success(row):
    """
    Regra de 'jogada de sucesso' comum em análise de futebol americano:
      1o down: ganhar >= 40% das jardas necessárias
      2o down: ganhar >= 60%
      3o/4o down: converter o first down (>= 100%)
    """
    down = row.get("down")
    ytg = row.get("yardsToGo")
    gained = row.get("playResult")
    if pd.isna(down) or pd.isna(ytg) or pd.isna(gained) or ytg == 0:
        return None
    ratio = gained / ytg
    if down == 1:
        return int(ratio >= 0.40)
    if down == 2:
        return int(ratio >= 0.60)
    return int(ratio >= 1.0)  # 3o e 4o down


def _play_effectiveness(row):
    """
    Score de efetividade da JOGADA (não do jogador). Escala aproximada em
    'valor de jardas'. Combina o resultado real com penalizações para
    eventos catastróficos, para que o treinador veja risco, não só média.

      base       = jardas ganhas (playResult)
      + bônus    se converteu (sucesso da jogada)
      - penalidade forte para sack e interceptação
    """
    gained = row.get("playResult")
    if pd.isna(gained):
        return None
    score = float(gained)

    if row.get("_success") == 1:
        score += 2.0

    pass_result = row.get("passResult")
    if pass_result == "S":       # sack
        score -= 6.0
    elif pass_result == "IN":    # interceptação
        score -= 12.0
    return score


def prepare_plays(plays):
    """Adiciona colunas de situação e efetividade ao DataFrame de jogadas."""
    df = plays.copy()

    df["dist_bucket"] = df["yardsToGo"].apply(_distance_bucket)
    df["field_bucket"] = df["absoluteYardlineNumber"].apply(_field_bucket)
    df["_success"] = df.apply(_play_success, axis=1)
    df["play_score"] = df.apply(_play_effectiveness, axis=1)

    # Só jogadas de passe têm passResult; marcamos o tipo de jogada.
    df["play_type"] = df["passResult"].apply(
        lambda x: "passe/dropback" if pd.notna(x) else "corrida/outro"
    )
    return df


# ---------------------------------------------------------------------------
# Efetividade de jogadores (pass rush e proteção)
# ---------------------------------------------------------------------------
def _calcular_idade(birth_date, referencia="2021-09-01"):
    """
    Idade (em anos) na data de referência (início da temporada 2021).
    Retorna None se a data de nascimento estiver ausente/invalida.
    """
    if pd.isna(birth_date):
        return None
    nasc = pd.to_datetime(birth_date, errors="coerce")
    if pd.isna(nasc):
        return None
    ref = pd.Timestamp(referencia)
    anos = ref.year - nasc.year - ((ref.month, ref.day) < (nasc.month, nasc.day))
    return int(anos)


def _perfil_jogadores(players):
    """
    Prepara os campos de perfil (birthDate, idade, height, weight) por nflId,
    para anexar às tabelas de efetividade.
    """
    perfil = players[["nflId", "birthDate", "height", "weight",
                      "collegeName"]].copy()
    # Alguns nomes de faculdade vêm com entidade HTML (ex.: "Texas A&amp;M").
    perfil["collegeName"] = perfil["collegeName"].str.replace(
        "&amp;", "&", regex=False)
    perfil["idade"] = perfil["birthDate"].apply(_calcular_idade)
    return perfil


def prepare_player_effectiveness(pff, players):
    """
    Gera duas tabelas de efetividade individual, cada uma já enriquecida com
    o perfil do jogador (data de nascimento, idade, altura, peso):
      - pass_rush: defensores por pressão (hit+hurry+sack) e por jogo
      - protection: bloqueadores por sacks/hits/hurries permitidos
    """
    df = pff.merge(players, on="nflId", how="left")
    perfil = _perfil_jogadores(players)

    for col in ["pff_hit", "pff_hurry", "pff_sack",
                "pff_sackAllowed", "pff_hitAllowed", "pff_hurryAllowed"]:
        df[col] = pd.to_numeric(df[col], errors="coerce").fillna(0)

    # --- Pass rush (defesa) ---
    rushers = df[df["pff_role"] == "Pass Rush"].copy()
    rushers["pressoes"] = rushers["pff_hit"] + rushers["pff_hurry"] + rushers["pff_sack"]
    pass_rush = (
        rushers.groupby(["nflId", "displayName", "officialPosition"])
        .agg(
            jogadas=("playId", "count"),
            sacks=("pff_sack", "sum"),
            hits=("pff_hit", "sum"),
            hurries=("pff_hurry", "sum"),
            pressoes=("pressoes", "sum"),
        )
        .reset_index()
    )
    pass_rush["taxa_pressao"] = (pass_rush["pressoes"] / pass_rush["jogadas"]).round(3)
    pass_rush = pass_rush.merge(perfil, on="nflId", how="left")
    pass_rush = pass_rush.sort_values("pressoes", ascending=False)

    # --- Proteção (ataque) ---
    blockers = df[df["pff_role"] == "Pass Block"].copy()
    blockers["falhas"] = (
        blockers["pff_sackAllowed"] + blockers["pff_hitAllowed"] + blockers["pff_hurryAllowed"]
    )
    protection = (
        blockers.groupby(["nflId", "displayName", "officialPosition"])
        .agg(
            jogadas=("playId", "count"),
            sacks_permitidos=("pff_sackAllowed", "sum"),
            hits_permitidos=("pff_hitAllowed", "sum"),
            hurries_permitidos=("pff_hurryAllowed", "sum"),
            falhas=("falhas", "sum"),
        )
        .reset_index()
    )
    # taxa_protecao: proporção de jogadas SEM falha (quanto maior, melhor)
    protection["taxa_protecao"] = (
        1 - protection["falhas"] / protection["jogadas"]
    ).round(3)
    protection = protection.merge(perfil, on="nflId", how="left")
    protection = protection.sort_values("taxa_protecao", ascending=False)

    return pass_rush, protection


# ---------------------------------------------------------------------------
# Ratings em estrelas (0 a 5) por posição
# ---------------------------------------------------------------------------
def _estrelas_por_percentil(serie):
    """
    Converte uma métrica numérica em nota de 0.5 a 5.0 estrelas (passo 0.5)
    com base no percentil dentro do grupo. Maior valor => mais estrelas.
    Métricas onde 'menor é melhor' devem ser invertidas antes de chamar.
    """
    # rank percentual (0..1); com poucos registros ainda funciona.
    pct = serie.rank(pct=True)
    # mapeia 0..1 para 1..10 (meias-estrelas) e divide por 2 -> 0.5..5.0
    passos = (pct * 9).round().astype("Int64") + 1  # 1..10
    return (passos / 2).astype(float)


def compute_player_ratings(pass_rush, protection, min_jogadas=30):
    """
    Gera um dicionário de ratings em estrelas por jogador e por papel.

    Para cada papel, define 5 características e converte cada uma em 0.5-5.0
    estrelas via percentil DENTRO do grupo (comparação com os pares).

    Retorna dois DataFrames:
      ratings_rush  : índice nflId, colunas = 5 atributos + estrelas
      ratings_prot  : idem para bloqueadores
    """
    # ---- Pass rushers (defesa) ----
    pr = pass_rush[pass_rush["jogadas"] >= min_jogadas].copy()
    if not pr.empty:
        pr["_sack_rate"] = pr["sacks"] / pr["jogadas"]
        pr["_hit_rate"] = pr["hits"] / pr["jogadas"]
        pr["_hurry_rate"] = pr["hurries"] / pr["jogadas"]
        # 5 características do pass rusher:
        pr["Pressão"] = _estrelas_por_percentil(pr["taxa_pressao"])
        pr["Finalização (sack)"] = _estrelas_por_percentil(pr["_sack_rate"])
        pr["Impacto (hit)"] = _estrelas_por_percentil(pr["_hit_rate"])
        pr["Perturbação (hurry)"] = _estrelas_por_percentil(pr["_hurry_rate"])
        pr["Volume/Durabilidade"] = _estrelas_por_percentil(pr["jogadas"])

    # ---- Bloqueadores (ataque) ----
    pt = protection[protection["jogadas"] >= min_jogadas].copy()
    if not pt.empty:
        pt["_sack_allow_rate"] = pt["sacks_permitidos"] / pt["jogadas"]
        pt["_hit_allow_rate"] = pt["hits_permitidos"] / pt["jogadas"]
        pt["_hurry_allow_rate"] = pt["hurries_permitidos"] / pt["jogadas"]
        # 5 características do bloqueador (menor permitido = melhor -> inverte com sinal):
        pt["Confiabilidade"] = _estrelas_por_percentil(pt["taxa_protecao"])
        pt["Proteção de sack"] = _estrelas_por_percentil(-pt["_sack_allow_rate"])
        pt["Proteção de hit"] = _estrelas_por_percentil(-pt["_hit_allow_rate"])
        pt["Proteção de hurry"] = _estrelas_por_percentil(-pt["_hurry_allow_rate"])
        pt["Volume/Durabilidade"] = _estrelas_por_percentil(pt["jogadas"])

    return pr, pt


# Atributos (em ordem) exibidos para cada papel
ATRIBUTOS_RUSH = ["Pressão", "Finalização (sack)", "Impacto (hit)",
                  "Perturbação (hurry)", "Volume/Durabilidade"]
ATRIBUTOS_PROT = ["Confiabilidade", "Proteção de sack", "Proteção de hit",
                  "Proteção de hurry", "Volume/Durabilidade"]

# Explicação breve de cada característica (mostrada no hover / tooltip).
DESC_ATRIBUTOS = {
    # Pass rusher
    "Pressão": "Com que frequência o jogador pressiona o QB (soma de "
               "sacks, hits e hurries por jogada). Quanto maior, melhor.",
    "Finalização (sack)": "Capacidade de derrubar o QB antes do passe "
                          "(sacks por jogada). Concretiza a pressão.",
    "Impacto (hit)": "Frequência com que acerta o QB no momento do passe "
                     "(hits por jogada), atrapalhando o lançamento.",
    "Perturbação (hurry)": "Frequência com que apressa o QB (hurries por "
                           "jogada), forçando decisões rápidas.",
    "Volume/Durabilidade": "Quantidade de jogadas disputadas: indica "
                           "carga de trabalho e presença em campo.",
    # Bloqueador
    "Confiabilidade": "Proporção de jogadas em que protege sem cometer "
                      "falha (não permite sack, hit nem hurry).",
    "Proteção de sack": "Raramente permite que seu defensor chegue a um "
                        "sack (menos sacks permitidos = mais estrelas).",
    "Proteção de hit": "Raramente permite que seu defensor acerte o QB "
                       "(menos hits permitidos = mais estrelas).",
    "Proteção de hurry": "Raramente permite que seu defensor apresse o QB "
                         "(menos hurries permitidos = mais estrelas).",
}


if __name__ == "__main__":
    plays, pff, players = load_raw()
    dfp = prepare_plays(plays)
    print("Jogadas preparadas:", dfp.shape)
    print(dfp[["down", "yardsToGo", "dist_bucket", "field_bucket",
               "_success", "play_score", "play_type"]].head(10).to_string(index=False))
